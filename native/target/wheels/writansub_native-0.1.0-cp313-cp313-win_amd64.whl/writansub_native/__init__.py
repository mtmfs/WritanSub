from .writansub_native import *

__doc__ = writansub_native.__doc__
if hasattr(writansub_native, "__all__"):
    __all__ = writansub_native.__all__